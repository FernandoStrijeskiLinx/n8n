/* eslint-disable import/no-cycle */
import { addRoutes } from './routes';

export const userManagementRouter = { addRoutes };
