/* eslint-disable import/no-cycle */
import { getInstance, UserManagementMailer } from './UserManagementMailer';

export { getInstance, UserManagementMailer };
